<?php
 phpinfo();